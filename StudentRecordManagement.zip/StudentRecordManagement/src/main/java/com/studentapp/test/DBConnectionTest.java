package com.studentapp.test;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnectionTest {
    public static void main(String[] args) {
        String jdbcURL = "jdbc:mysql://localhost:3306/student_db"; // Replace with your DB name
        String dbUser = "root"; // Replace with your MySQL username
        String dbPassword = "root"; // Replace with your MySQL password

        try {
            Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
            System.out.println("✅ Database connected successfully!");
            connection.close();
        } catch (Exception e) {
            System.out.println("❌ Connection failed:");
            e.printStackTrace();
        }
    }
}
